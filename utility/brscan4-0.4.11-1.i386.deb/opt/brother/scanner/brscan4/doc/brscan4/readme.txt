This software is based in part on the work of the Independent JPEG Group.
